Place the pnSelf.exe file and the config.json file together in one directory. The directory can be placed anywhere you like.
