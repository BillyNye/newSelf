Place the pnSelf folder in your user directory, and the pnSelf-launch executable anywhere else.
